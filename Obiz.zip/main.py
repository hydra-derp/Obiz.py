import asyncio
import functools
import itertools
import math
import random
import os
from keep_alive import keep_alive
from asyncio import sleep
import json
import aiohttp
from discord.ext.commands import cooldown, BucketType
from discord.utils import get
import datetime
from discord.utils import find

import discord
from async_timeout import timeout
from discord.ext import commands

default = 0
teal = 0x1abc9c
dark_teal = 0x11806a
green = 0x2ecc71
dark_green = 0x1f8b4c
blue = 0x3498db
dark_blue = 0x206694
purple = 0x9b59b6
dark_purple = 0x71368a
magenta = 0xe91e63
dark_magenta = 0xad1457
gold = 0xf1c40f
dark_gold = 0xc27c0e
orange = 0xe67e22
dark_orange = 0xa84300
red = 0xe74c3c
dark_red = 0x992d22
lighter_grey = 0x95a5a6
dark_grey = 0x607d8b
light_grey = 0x979c9f
darker_grey = 0x546e7a
blurple = 0x7289da
greyple = 0x99aab5



bot = commands.Bot(
	command_prefix="o.", 
	case_insensitive=True  
)

bot.author_id = 586858636152799246

@bot.event 
async def on_ready():
    print("I'm in")
    print(bot.user)
    bot.loop.create_task(status_task())

bot.remove_command('help')

@bot.event
async def status_task():
  while True: 
   await bot.change_presence(activity=discord.Game(name=f'Obiz!|o.help'))
   await sleep(3)
   await bot.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name=f'{len(bot.guilds)} servers'))
   await sleep(2)
   await bot.change_presence(activity=discord.Game(name=f'The Economy'))
   await sleep(2)

@bot.event
async def on_guild_join(guild):
    general = find(lambda x: x.name == 'general',  guild.text_channels)
    if general and general.permissions_for(guild.me).send_messages:
        await general.send('```css\nHello {}! \n\nUse\n.help\nto view commands this bot offers!\n\nUse\n.status\nto see errors and next updates for the bot.\n\nUse\no.information\nto get info on the bot.\n\n.\n\nIs my prefix.```'.format(guild.name))


@bot.command(name='Ping latency',aliases =['ping'])
async def ping(ctx):
  await ctx.reply(f'**Pong!** \nLatency : {round(bot.latency * 1000)}ms', mention_author=False)

extensions = [
  'cogs.cog_example',
  'cogs.cog_one',
  'cogs.cog_two',
  'cogs.cog_zthree',
]

@bot.command(pass_context=True, aliases=["info"])
async def information(ctx):
   author = ctx.message.author
   await ctx.reply("```diff\nRequested by: [{0}]\n\n[_Information:_]\n\nVersion:\n-> 9.7.3\n\n-> Discord.py\n\n_Creators:_\n\nFounder and Developer:\n+> The Mid#8068\nServer Developer:\n+> TheMid#8068\n\n_Command Help and Invite:_\n+> https://bit.ly/Obiz_invite\n\nRequested at: {1}```".format(author,datetime.datetime.utcnow()), mention_author=False)

@bot.command(pass_context=True, aliases=["stat"])
async def status(ctx):
   author = ctx.message.author
   await ctx.reply("```diff\nRequested by: [{0}]\n\n[_Information:_]\n\n__Problems getting fixed:__\n-> Json Store error:\nUnexpected balance deletion in economy, therefore disabled.\n\n__Big Updates Soon:__\n+> Music\n+> Pets \n+> Better UI\n\nRequested at: {1}```".format(author,datetime.datetime.utcnow()), mention_author=False)

@bot.command(pass_context=True)
@commands.has_permissions(administrator=True)
async def purge(ctx, limit: int):
        await ctx.channel.purge(limit=limit)
        await ctx.send('Cleared by {}'.format(ctx.author.mention))
        await ctx.message.delete()

@bot.command(pass_context=True)
@commands.has_permissions(administrator=True)
async def pang(self, ctx, *, question):
       for i in range(1,11):
         await ctx.reply(f'Hey! {question}')

@purge.error
async def clear_error(ctx, error):
    if isinstance(error, commands.MissingPermissions):
        await ctx.send("Uh Oh! Error Report:\n`Missing Permissions`")


@bot.command()
async def rand(ctx):

    # checks the author is responding in the same channel
    # and the message is able to be converted to a positive int
    def check(msg):
        return msg.author == ctx.author and msg.content.isdigit() and \
               msg.channel == ctx.channel

    await ctx.reply("Type a number from 0", mention_author=False)
    msg1 = await bot.wait_for("message", check=check)
    x = 0
    y = int(msg1.content)
    if x < y:
        value = random.randint(x,y)
        await ctx.reply(f"You got {value}.", mention_author=False)

@bot.command()
async def kill(ctx, member: discord.Member):
    kill_messages = [
        f'{ctx.author} killed {member} with a baseball bat', 
        f'{ctx.author} killed {member} with a frying pan',
        f'{ctx.author} killed {member} with boredom',
        f'{ctx.author} killed {member} with a 4mm round',
        f'{ctx.author} killed {member} cause why not',
        f'{ctx.author} killed {member} with a bagguette',
        f'{ctx.author} killed {member} with a feather',
        f'{ctx.author} killed {member} with large noodle',
        f'{ctx.author} killed {member} with a child',
        f'{ctx.author} killed {member} with spicy ramen noodles',
        f'{ctx.author} killed {member} with witch craft',
        f'{ctx.author} killed {member} a diamond sword',
        f'{ctx.author} killed {member} with the orphan obliterator',
        f'{ctx.author} killed {member} with a "yo mama" joke',
        f'{ctx.author} killed {member} in Minecraft hardcore',
        f'{ctx.author} killed {member} by running them over in a tractor',
        f'{ctx.author} killed {member} by sneezing on them',
        f'{ctx.author} killed {member} with 300 nukes',
        f'{ctx.author} killed {member} in Roblox Royale High',
        f'{ctx.author} killed {member} by looking a bit too ugly',
        f'{ctx.author} killed {member} by being short',
        f'{ctx.author} killed {member} with a happy meal',
        f'{ctx.author} killed {member} with chicky nuggies'

    ]

    embed = discord.Embed(title=random.choice(kill_messages), color=greyple)
    embed.timestamp = datetime.datetime.utcnow()
    await ctx.reply(embed=embed, mention_author=False)


#Moderator command##
@commands.has_permissions(kick_members=True)
@bot.command()
async def kick(ctx, user: discord.Member, *, reason="No reason provided"):
        await user.kick(reason=reason)
        kick = discord.Embed(title=f":boot: Kicked `{user.name}`!", description=f"Reason: {reason}\nBy: `{ctx.author.mention}`",colour = discord.Colour.blurple())
        kick.set_thumbnail(url=user.avatar_url)
        kick.timestamp = datetime.datetime.utcnow()
        await ctx.message.delete()
        await ctx.channel.send(embed=kick)
        await user.send(embed=kick)

@commands.has_permissions(kick_members=True)
@bot.command()
async def brendon(ctx, user: discord.Member, *, reason="Brendon Blocker"):
        await user.kick(reason=reason)
        kick = discord.Embed(title=f":boot: Kicked {user.name}!", description=f"Reason: {reason}\nBy: {ctx.author.mention}",colour = discord.Colour.dark_gold())
        kick.set_thumbnail(url=user.avatar_url)
        kick.timestamp = datetime.datetime.utcnow()
        await ctx.message.delete()
        await ctx.channel.send(embed=kick)
        await user.send(embed=kick)

##Economy Command######################################
@bot.event
async def on_command_error(ctx,error):

  error_timer = 'Please try again in {:.2f} seconds'.format(error.retry_after)

  user = ctx.author
  embed = discord.Embed(title = "Slow down, you are on Cool down!", description= error_timer, color=dark_magenta)
  embed.set_author(name="Cooldown", icon_url="https://lh3.googleusercontent.com/proxy/3klFlwZ5v7DVIGuUwFg2H2d-Cu5HGHybeZktgsFCMtoDLDPIxqxxrrsN6_arEjvMAY-7GOT-pxXLcnDeh6w6HSwsE6dbK3mTdageXAQr-UEYRjpReRWLp4sr39EazcI")
  embed.set_thumbnail(url=user.avatar_url)
  embed.timestamp = datetime.datetime.utcnow()
  if isinstance(error, commands.CommandOnCooldown):
    await ctx.reply(embed=embed, mention_author=False)


mainshop = [{"name":"Dust","price":1,"description":"Collectible"},
            {"name":"CheeseToastie","price":100,"description":"Food"},
            {"name":"BasketballJersey","price":250,"description":"Collectible"},
            {"name":"SportsCar","price":500,"description":"Travel"},
            {"name":"Toyball","price":1000,"description":"Collectible"},
            {"name":"PC","price":10000,"description":"Gaming"},
            {"name":"Rocket","price":100000,"description":"Travel"},
            {"name":"FormulaOneCar","price":1000000,"description":"Racing"},
            {"name":"Factory","price":1500000,"description":"Work Consumable"},
            {"name":"Stonksicon","price":2000,"description":"Collectible, Possible Stonks"},
            {"name":"Parthane","price":1000000000,"description":"Juice Box"},
            {"name":"DeluxeParthane","price":1500000000,"description":"Juice Box"},
            {"name":"ParthaneRocket","price":1000000000000,"description":"Juice Box"},
            {"name":"ParthanePlanet","price":1000000000000000,"description":"Juice Box"}
            ]

@bot.command(aliases=['bal'])
async def balance(ctx):
    await open_account(ctx.author)
    user = ctx.author

    users = await get_bank_data()

    wallet_amt = users[str(user.id)]["wallet"]
    bank_amt = users[str(user.id)]["bank"]

    em = discord.Embed(title=f'{ctx.author.name}s Money Amount',color = discord.Color.green())
    em.set_author(name="OBIZ bank",icon_url=user.avatar_url)
    em.add_field(name="`Wallet Balance`", value=wallet_amt, inline=False)
    em.add_field(name="`Bank Balance`",value=bank_amt, inline=False)
    em.set_thumbnail(url="https://www.freeiconspng.com/uploads/bank-icon-5.png")
    em.timestamp = datetime.datetime.utcnow()
    await ctx.reply(embed=em, mention_author=False)

@bot.command(aliases=["r"])
async def rich(ctx,member:discord.Member):
        await open_account(member)
        user= ctx.author
        users = await get_bank_data()

        wallet_amt = users[str(member.id)]["wallet"]
        bank_amt = users[str(member.id)]["bank"]

        embed = discord.Embed(
            title = f"{member}'s balance",
            color = blurple
        )
        embed.set_author(name="Money Balance", icon_url=member.avatar_url)
        embed.add_field(name='`Wallet`', value= wallet_amt, inline=False)
        embed.add_field(name='`Bank`', value= bank_amt, inline=False)
        embed.set_thumbnail(url="https://www.freeiconspng.com/uploads/bank-icon-5.png")
        embed.timestamp = datetime.datetime.utcnow()
        embed.set_footer(text= "💰 This is not networth 💰")
        await ctx.channel.send(embed=embed)

@bot.command()
@commands.cooldown(1, 10, commands.BucketType.user)
async def beg(ctx):
    await open_account(ctx.author)
    user = ctx.author

    users = await get_bank_data()

    earnings = random.randrange(101)

    await ctx.reply(f'{ctx.author.mention} Got {earnings} coins!!', mention_author=False)

    users[str(user.id)]["wallet"] += earnings

    with open("mainbank.json",'w') as f:
        json.dump(users,f)

@bot.command()
@commands.is_owner() 
async def ownerbeg(ctx):
    await open_account(ctx.author)
    user = ctx.author

    users = await get_bank_data()

    earnings = random.randrange(101)*100

    await ctx.reply(f'{ctx.author.mention} Got {earnings} coins!!', mention_author=False)

    users[str(user.id)]["wallet"] += earnings

    with open("mainbank.json",'w') as f:
        json.dump(users,f)


@bot.command()
async def onlypan(ctx):
    await open_account(ctx.author)
    user = ctx.author

    users = await get_bank_data()

    earnings = 10000

    await ctx.reply(f'{ctx.author.mention} Got {earnings} coins!!', mention_author=False)

    users[str(user.id)]["wallet"] += earnings

    with open("mainbank.json",'w') as f:
        json.dump(users,f)


@bot.command()
@commands.cooldown(1, 30, commands.BucketType.user)
async def work(ctx):
    await open_account(ctx.author)
    user = ctx.author

    users = await get_bank_data()

    earnings = random.randrange(10000)

    occupation = [
      "by working as a Polise",
      "by working as a Donktor",
      "by working as a FearFighter",
      "by working as a Shouldeir",
      "by working as a Wreferee",
      "by working as a Moosician",
      "by working as a Baicker"
    ]
    randomjob = random.choice(occupation)

    embed= discord.Embed(title="You have worked for 6 hours", color=random.randint(0, 0xffffff))
    embed.set_author(name="Work", icon_url="https://www.pngarts.com/files/7/Remote-Work-PNG-Image-Transparent.png")
    embed.set_thumbnail(url=user.avatar_url)
    embed.add_field(name=earnings, value=randomjob)
    embed.timestamp = datetime.datetime.utcnow()

    await ctx.reply(embed=embed, mention_author=False)
    if users[user.id]["bag"]["Factory"] > 0:
      users[str(user.id)]["wallet"] += earnings*2
    else:
     users[str(user.id)]["wallet"] += earnings
     #await ctx.reply("Lol u failed")

    

    with open("mainbank.json",'w') as f:
        json.dump(users,f)

@bot.command()
@commands.cooldown(1, 600, commands.BucketType.user)
async def stonks(ctx):
    await open_account(ctx.author)
    user = ctx.author

    users = await get_bank_data()

    earnings = random.randrange(6)*10000-10000

    em = discord.Embed(Title="Your Stonks:", color=gold)
    em.set_author(name="Stonks result", icon_url="https://i.imgflip.com/44bx3m.png")
    em.add_field(name="Earnings", value=earnings)
    em.set_thumbnail(url=user.avatar_url)
    em.set_footer(text="!!Unstable Money!!")
    em.timestamp = datetime.datetime.utcnow()

    users[str(user.id)]["wallet"] += earnings

    with open("mainbank.json",'w') as f:
        json.dump(users,f)

    await ctx.reply(embed=em, mention_author=False)




@bot.command(aliases=['wd'])
async def withdraw(ctx,amount = None):
    await open_account(ctx.author)
    if amount == None:
        await ctx.reply("Please enter the amount", mention_author=False)
        return

    bal = await update_bank(ctx.author)

    if amount == 'all':
        amount = bal[1]

    amount = int(amount)

    if amount > bal[1]:
        await ctx.reply('You do not have sufficient balance', mention_author=False)
        return
    if amount < 0:
        await ctx.reply('Amount must be positive!', mention_author=False)
        return

    await update_bank(ctx.author,amount)
    await update_bank(ctx.author,-1*amount,'bank')
    await ctx.reply(f'{ctx.author.mention} You withdrew `{amount}` coins', mention_author=False)


@bot.command(aliases=['dep'])
async def deposit(ctx,amount = None):
    await open_account(ctx.author)
    if amount == None:
        await ctx.reply("Please enter the amount", mention_author=False)
        return
    

    bal = await update_bank(ctx.author)

    if amount == 'all':
        amount = bal[0]

    amount = int(amount)

    if amount > bal[0]:
        await ctx.reply('You do not have sufficient balance', mention_author=False)
        return
    if amount < 0:
        await ctx.reply('Amount must be positive!', mention_author=False)
        return

    await update_bank(ctx.author,-1*amount)
    await update_bank(ctx.author,amount,'bank')
    await ctx.reply(f'{ctx.author.mention} You deposited `{amount}` coins', mention_author=False)


@bot.command(aliases=['sm'])
@commands.cooldown(1, 30, commands.BucketType.user)
async def send(ctx,member : discord.Member,amount = None):
    await open_account(ctx.author)
    await open_account(member)
    user = ctx.author
    if amount == None:
        await ctx.reply("Please enter the amount", mention_author=False)
        return

    bal = await update_bank(ctx.author)
    if amount == 'all':
        amount = bal[0]

    amount = int(amount)

    if amount > bal[0]:
        await ctx.reply('You do not have sufficient balance', mention_author=False)
        return
    if amount < 0:
        await ctx.reply('Amount must be positive!', mention_author=False)
        return

    await update_bank(ctx.author,-1*amount)
    await update_bank(member,amount,'bank')


    embed = discord.Embed(Title="Money Sent!", color=gold, description="Money Transfered Successfully")
    embed.set_author(name=f'Money Tansfer to `{member}`', icon_url="https://icons-for-free.com/iconfiles/png/512/green+right+rightarrow+icon-1320183462288899532.png")
    embed.add_field(name="`Money sent:`", value=f'`{amount}`')
    embed.set_image(url=member.avatar_url)
    embed.set_thumbnail(url=user.avatar_url)
    embed.set_footer(text=f'`{ctx.author.mention}` is such a nice person.')
    embed.timestamp = datetime.datetime.utcnow()

    await ctx.reply(embed=embed, mention_author=False)


@bot.command(aliases=['rb'])
async def rob(ctx,member : discord.Member):
    await open_account(ctx.author)
    await open_account(member)
    bal = await update_bank(member)


    if bal[0]<100:
        await ctx.reply('It is useless to rob', mention_author=False)
        return

    earning = random.randrange(0,bal[0])

    await update_bank(ctx.author,earning)
    await update_bank(member,-1*earning)
    await ctx.reply(f'{ctx.author.mention} You robbed `{member}` and got `{earning}` coins', mention_author=False)


@bot.command(name="slots")
@commands.cooldown(1, 30, commands.BucketType.user)
async def slots(ctx,amount = None):
    await open_account(ctx.author)
    if amount == None:
        await ctx.reply("Please enter the amount", mention_author=False)
        return

    bal = await update_bank(ctx.author)

    amount = int(amount)

    if amount > bal[0]:
        await ctx.reply('You do not have sufficient balance', mention_author=False)
        return
    if amount < 0:
        await ctx.reply('Amount must be positive!', mention_author=False)
        return
    final = []
    for i in range(3):
        a = random.choice(['X','O','Q'])

        final.append(a)
    
    em1 = discord.Embed(Title="Slot outcome", color=dark_green)
    em1.set_author(name="Win!", icon_url="https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Happy_smiley_face.png/480px-Happy_smiley_face.png")
    em1.add_field(name="`Slots:`", value=(final))
    em1.set_footer(text="Winner winner chicken dinner!")
    em1.timestamp = datetime.datetime.utcnow()

    em2 = discord.Embed(Title="Slot outcome", color=dark_red)
    em2.set_author(name="Lose!", icon_url="https://freepikpsd.com/media/2019/10/emoji-sad-png-6.png")
    em2.add_field(name="`Slots:`", value=(final))
    em2.set_footer(text="Better luck next time")
    em2.timestamp = datetime.datetime.utcnow()

    winner_money = amount+amount/2
    loser_money = -1*amount

    if final[0] == final[1] or final[1] == final[2] or final[0] == final[2]:
        await update_bank(ctx.author,winner_money)
        em1.add_field(name="`Winnings:`", value=winner_money, inline = False)
        await ctx.reply(embed=em1, mention_author=False)
    else:
        await update_bank(ctx.author,loser_money)
        em2.add_field(name="`Winnings:`", value=loser_money, inline = False)
        await ctx.reply(embed=em2, mention_author=False)


@bot.command()
async def shop(ctx):
    user = ctx.author

    em = discord.Embed(title = "Items to buy", color=discord.Color.green())
    em.set_author(name="OBIZ Shop", icon_url="https://www.iconpacks.net/icons/2/free-store-icon-2017-thumb.png")
    em.set_thumbnail(url=user.avatar_url)
    em.timestamp = datetime.datetime.utcnow()

    for item in mainshop:
        name = item["name"]
        price = item["price"]
        desc = item["description"]
        em.add_field(name = name, value = f"${price} | {desc}", inline=False)

    await ctx.reply(embed = em, mention_author=False)



@bot.command()
async def buy(ctx,item,amount = 1):
    await open_account(ctx.author)

    res = await buy_this(ctx.author,item,amount)

    if not res[0]:
        if res[1]==1:
            await ctx.reply("That Object isn't there!", mention_author=False)
            return
        if res[1]==2:
            await ctx.reply(f"You don't have enough money in your wallet to buy {amount} {item}", mention_author=False)
            return


    await ctx.reply(f"You just bought {amount} {item}", mention_author=False)


@bot.command(aliases=["inv"])
async def bag(ctx):
    await open_account(ctx.author)
    user = ctx.author
    users = await get_bank_data()

    try:
        bag = users[str(user.id)]["bag"]
    except:
        bag = []


    em = discord.Embed(title = "Inventory", description="All your belongings", color=discord.Color.green())
    em.set_author(name="Bag", icon_url="https://cdn.hipwallpaper.com/i/27/80/HnveSo.png")
    em.set_thumbnail(url=user.avatar_url)
    for item in bag:
        name = item["item"]
        amount = item["amount"]

        em.add_field(name = name, value = amount) 
    em.timestamp = datetime.datetime.utcnow()   

    await ctx.reply(embed = em, mention_author=False)


async def buy_this(user,item_name,amount):
    item_name = item_name.lower()
    name_ = None
    for item in mainshop:
        name = item["name"].lower()
        if name == item_name:
            name_ = name
            price = item["price"]
            break

    if name_ == None:
        return [False,1]

    cost = price*amount

    users = await get_bank_data()

    bal = await update_bank(user)

    if bal[0]<cost:
        return [False,2]


    try:
        index = 0
        t = None
        for thing in users[str(user.id)]["bag"]:
            n = thing["item"]
            if n == item_name:
                old_amt = thing["amount"]
                new_amt = old_amt + amount
                users[str(user.id)]["bag"][index]["amount"] = new_amt
                t = 1
                break
            index+=1 
        if t == None:
            obj = {"item":item_name , "amount" : amount}
            users[str(user.id)]["bag"].append(obj)
    except:
        obj = {"item":item_name , "amount" : amount}
        users[str(user.id)]["bag"] = [obj]        

    with open("mainbank.json","w") as f:
        json.dump(users,f)

    await update_bank(user,cost*-1,"wallet")

    return [True,"Worked"]
    

@bot.command()
async def sell(ctx,item,amount = 1):
    await open_account(ctx.author)

    res = await sell_this(ctx.author,item,amount)

    if not res[0]:
        if res[1]==1:
            await ctx.reply("That Object isn't there!", mention_author=False)
            return
        if res[1]==2:
            await ctx.reply(f"You don't have {amount} {item} in your bag.", mention_author=False)
            return
        if res[1]==3:
            await ctx.reply(f"You don't have {item} in your bag.", mention_author=False)
            return

    await ctx.reply(f"You just sold {amount} {item}.", mention_author=False)

async def sell_this(user,item_name,amount,price = None):
    item_name = item_name.lower()
    name_ = None
    for item in mainshop:
        name = item["name"].lower()
        if name == item_name:
            name_ = name
            if price==None:
                price = 0.7* item["price"]
            break

    if name_ == None:
        return [False,1]

    cost = price*amount

    users = await get_bank_data()

    bal = await update_bank(user)


    try:
        index = 0
        t = None
        for thing in users[str(user.id)]["bag"]:
            n = thing["item"]
            if n == item_name:
                old_amt = thing["amount"]
                new_amt = old_amt - amount
                if new_amt < 0:
                    return [False,2]
                users[str(user.id)]["bag"][index]["amount"] = new_amt
                t = 1
                break
            index+=1 
        if t == None:
            return [False,3]
    except:
        return [False,3]    

    with open("mainbank.json","w") as f:
        json.dump(users,f)

    await update_bank(user,cost,"wallet")

    return [True,"Worked"]


@bot.command(aliases = ["lb"])
async def leaderboard(ctx,x: int = 4):
    users = await get_bank_data()
    leader_board = {}
    total = []
    for user in users:
        name = int(user)
        total_amount = users[user]["wallet"] + users[user]["bank"]
        leader_board[total_amount] = name
        total.append(total_amount)

    total = sorted(total, reverse=True)

    em = discord.Embed(title=f"Top {x} Richest People", color=random.randint(0, 0xffffff))
    index = 1
    for amt in total:
        id_ = leader_board[amt]
        member = await ctx.guild.fetch_member(id_) #your existing line
        if member is None:
            raise ValueError(f"Member with id {id_} not found")
            name = "Unknown"
            index += 1
            em.add_field(name=f"{index}. {name}", value=f"{amt}", inline=False)
        else:
          name = member.name
          em.add_field(name=f"{index}. {name}", value=f"{amt}", inline=False)
        if index == x:
            break
        else:
            index += 1

    em.timestamp = datetime.datetime.utcnow()
    await ctx.reply(embed=em, mention_author=False)

'''
    em.set_author(name="leaderboard", icon_url="https://lh3.googleusercontent.com/proxy/oxknQ8nD3fL6VI_F0JBOV8xAusT1GMbtWaD1Ms6vLPZVHOhHNeGwMnZiQTIzMviuuiSnaV9XCZZxUpNLDccJuAmN")
'''

async def open_account(user):

    users = await get_bank_data()

    if str(user.id) in users:
        return False
    else:
        users[str(user.id)] = {}
        users[str(user.id)]["wallet"] = 0
        users[str(user.id)]["bank"] = 0

    with open('mainbank.json','w') as f:
        json.dump(users,f)

    return True


async def get_bank_data():
    with open('mainbank.json','r') as f:
        users = json.load(f)

    return users


async def update_bank(user,change=0,mode = 'wallet'):
    users = await get_bank_data()

    users[str(user.id)][mode] += change

    with open('mainbank.json','w') as f:
        json.dump(users,f)
    bal = users[str(user.id)]['wallet'],users[str(user.id)]['bank']
    return bal

########################################################
##################PETS##################################

########################################################
@bot.command()
async def invites(ctx):
    totalInvites = 0
    for i in await ctx.guild.invites():
        if i.inviter == ctx.author:
            totalInvites += i.uses
    await ctx.send(f"You've invited {totalInvites} member{'' if totalInvites == 1 else 's'} to the server!", mention_author=False)


##Meme Command##
@bot.command(pass_context=True)
async def meme(ctx):
    
  embed1 = discord.Embed(title="Obiz | Meme", description="memes from r/dankmemes",colour = discord.Colour.green())


  async with aiohttp.ClientSession() as cs:
    async with cs.get('https://www.reddit.com/r/dankmemes/new.json?sort=hot') as r:
        res = await r.json()
        embed1.set_image(url=res['data']['children'] [random.randint(0, 26)]['data']['url'])
        embed1.timestamp = datetime.datetime.utcnow()
        await ctx.reply(embed=embed1, mention_author=False)

####
@bot.command(pass_context=True)
async def mcmeme(ctx):
    
  embed2 = discord.Embed(title="Obiz | minecraft meme", description="memes from r/MinecraftMemes",colour = discord.Colour.green())


  async with aiohttp.ClientSession() as cs:
    async with cs.get('https://www.reddit.com/r/MinecraftMemes/new.json?sort=hot') as r:
        res = await r.json()
        embed2.set_image(url=res['data']['children'] [random.randint(0, 26)]['data']['url'])
        embed2.timestamp = datetime.datetime.utcnow()
        await ctx.reply(embed=embed2, mention_author=False)
##fletcher##
@bot.command(pass_context=True)
async def animeme(ctx):
    
  embed = discord.Embed(title="Obiz | Anime Memes", description="from r/Animemes",colour = discord.Colour.green())


  async with aiohttp.ClientSession() as cs:
    async with cs.get('https://www.reddit.com/r/Animemes/new.json?sort=hot') as r:
        res = await r.json()
        embed.set_image(url=res['data']['children'] [random.randint(0, 25)]['data']['url'])
        embed.timestamp = datetime.datetime.utcnow()
        await ctx.reply(embed=embed, mention_author=False)

@bot.command(pass_context=True)
async def hentai(ctx):
    
  embed = discord.Embed(title="Obiz | NSFW", description="Hidden Command",colour = discord.Colour.red())


  async with aiohttp.ClientSession() as cs:
    async with cs.get('https://www.reddit.com/r/hentai/new.json?sort=hot') as r:
        res = await r.json()
        embed.set_image(url=res['data']['children'] [random.randint(0, 25)]['data']['url'])
        embed.timestamp = datetime.datetime.utcnow()
        await ctx.reply(embed=embed, mention_author=False)

@bot.command(pass_context=True)
async def porn(ctx):
    
  embed = discord.Embed(title="Obiz | NSFW", description="Hidden Command",colour = discord.Colour.red())


  async with aiohttp.ClientSession() as cs:
    async with cs.get('https://www.reddit.com/r/EngineeringPorn/new.json?sort=hot') as r:
        res = await r.json(content_type=None)
        embed.set_image(url=res['data']['children'] [random.randint(0, 25)]['data']['url'])
        embed.timestamp = datetime.datetime.utcnow()
        await ctx.reply(embed=embed, mention_author=False)

@bot.command(pass_context=True)
async def ass(ctx):
    
  embed = discord.Embed(title="Obiz | NSFW", description="Hidden Command",colour = discord.Colour.red())


  async with aiohttp.ClientSession() as cs:
    async with cs.get('https://www.reddit.com/r/ass/new.json?sort=hot') as r:
        res = await r.json()
        embed.set_image(url=res['data']['children'] [random.randint(0, 25)]['data']['url'])
        embed.timestamp = datetime.datetime.utcnow()
        await ctx.reply(embed=embed, mention_author=False)

@bot.command(pass_context=True)
async def tit(ctx):
    
  embed = discord.Embed(title="Obiz | NSFW", description="Hidden Command",colour = discord.Colour.red())


  async with aiohttp.ClientSession() as cs:
    async with cs.get('https://www.reddit.com/r/TittyTime/new.json?sort=hot') as r:
        res = await r.json()
        embed.set_image(url=res['data']['children'] [random.randint(0, 25)]['data']['url'])
        embed.timestamp = datetime.datetime.utcnow()
        await ctx.reply(embed=embed, mention_author=False)

@bot.command(pass_context=True)
async def pussy(ctx):
    
  embed = discord.Embed(title="Obiz | NSFW", description="Hidden Command",colour = discord.Colour.red())


  async with aiohttp.ClientSession() as cs:
    async with cs.get('https://www.reddit.com/r/pussy/new.json?sort=hot') as r:
        res = await r.json()
        embed.set_image(url=res['data']['children'] [random.randint(0, 25)]['data']['url'])
        embed.timestamp = datetime.datetime.utcnow()
        await ctx.reply(embed=embed, mention_author=False)

@bot.command()
async def invitebot(ctx):
  embed = discord.Embed(title="Obiz | Bot Invite", description="Invite the bot! for NSFW or another Server!",colour = discord.Colour.green()) 

  embed.add_field(name="**Bot Invite link**", value="https://discord.com/api/oauth2/authorize?client_id=771275541020934144&permissions=4228906227&scope=bot")

  embed.set_footer(text="Q.Can Mid see I have used a command?\nA. No ")
  embed.timestamp = datetime.datetime.utcnow()
  await ctx.reply(embed=embed, mention_author=False)

##Moderator##

@bot.event
async def on_raw_reaction_add(payload):
  message_id = payload.message_id 
  if message_id == 832218366282301460 :
    guild_id = payload.guild_id
    guild = discord.utils.find(lambda g : g.id == guild_id, bot.guilds)

    role = discord.utils.get(guild.roles, name=payload.emoji.name)

    if role is not None:
      member = discord.utils.find(lambda m : m.id == payload.user_id , guild.members)
      if member is not None:
        await member.add_roles(role)
        print(role.name)
        print('Done')
      else:
        print('member not found')
    else:
      print('role not found')


@bot.event
async def on_raw_reaction_remove(payload):
  message_id = payload.message_id 
  if message_id == 832218366282301460 :
    guild_id = payload.guild_id
    guild = discord.utils.find(lambda g : g.id == guild_id, bot.guilds)

    role = discord.utils.get(guild.roles, name=payload.emoji.name)

    if role is not None:
      member = discord.utils.find(lambda m : m.id == payload.user_id , guild.members)
      if member is not None:
        await member.remove_roles(role)
        print(role.name)
        print('Done')
      else:
        print('member not found')
    else:
      print('role not found') 

##polls##
@bot.command()
async def poll(ctx, question, option1=None, option2=None):
  if option1==None and option2==None:
    await ctx.channel.purge(limit=1)
    message = await ctx.send(f"```New poll: \n{question}```\n**🔵 = Yes**\n**🟣 = No**")
    await message.add_reaction('🔵')
    await message.add_reaction('🟣')
  elif option1==None:
    await ctx.channel.purge(limit=1)
    message = await ctx.send(f"```New poll: \n{question}```\n**🔵 = {option1}**\n**🟣 = No**")
    await message.add_reaction('🔵')
    await message.add_reaction('🟣')
  elif option2==None:
    await ctx.channel.purge(limit=1)
    message = await ctx.send(f"```New poll: \n{question}```\n**🔵 = Yes**\n**🟣 = {option2}**")
    await message.add_reaction('🔵')
    await message.add_reaction('🟣')
  else:
    await ctx.channel.purge(limit=1)
    message = await ctx.send(f"```New poll: \n{question}```\n**🔵 = {option1}**\n**🟣 = {option2}**")
    await message.add_reaction('🔵')
    await message.add_reaction('🟣')
####################################################

if __name__ == '__main__':  
	for extension in extensions:
		bot.load_extension(extension)

keep_alive() 
token = os.environ.get("DISCORD_BOT_SECRET") 
bot.run(token) 

