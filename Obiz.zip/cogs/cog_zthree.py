import discord
import random
from discord.ext import commands
import aiohttp
import json
import os

bot = commands.Bot(
	command_prefix=".", 
	case_insensitive=True  
)

def __init__(self, bot): 
   self.bot = bot

class economy (commands.Cog, name = '4.Economy'):
  pass

  




  
def setup(bot):
	bot.add_cog(economy(bot))