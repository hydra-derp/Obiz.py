import discord
import random
from discord.ext import commands
import aiohttp
import logging
import asyncio
import datetime
from discord.utils import get
log = logging.getLogger('discord')

bot = commands.Bot(
	command_prefix=".", 
	case_insensitive=True  
)

default = 0
teal = 0x1abc9c
dark_teal = 0x11806a
green = 0x2ecc71
dark_green = 0x1f8b4c
blue = 0x3498db
dark_blue = 0x206694
purple = 0x9b59b6
dark_purple = 0x71368a
magenta = 0xe91e63
dark_magenta = 0xad1457
gold = 0xf1c40f
dark_gold = 0xc27c0e
orange = 0xe67e22
dark_orange = 0xa84300
red = 0xe74c3c
dark_red = 0x992d22
lighter_grey = 0x95a5a6
dark_grey = 0x607d8b
light_grey = 0x979c9f
darker_grey = 0x546e7a
blurple = 0x7289da
greyple = 0x99aab5


class MainCommands (commands.Cog, name = '1.Main Commands'):
 ''' These are the main Commands'''

 def __init__(self, bot):
   self.bot = bot

 ###main commands start here###
 
 @commands.command(pass_context=True, name="Help")
 async def help(self, ctx):
   author = ctx.message.author
   user1 = ctx.author


   embed = discord.Embed(
    colour = dark_green
   )
   embed.set_thumbnail(url=user1.avatar_url)

   embed.set_author(name='Obiz | HELP',icon_url="https://cdn2.iconfinder.com/data/icons/bitsies/128/Info-256.png")

   embed.add_field(name='Help', value = '`o.help` displays this embed.',inline = False)

   embed.add_field(name='Moderating', value = '`o.help2` displays server managing commands.',inline = False)

   embed.add_field(name='Entertainment',value='`o.help3` displays all fun commands.', inline = False)

   embed.add_field(name='Miscellaneous',value='`o.help4` displays other commands.', inline = False)

   embed.add_field(name='More',value='`Website [temp]:` https://bit.ly/Obiz_invite', inline = False)

   embed.timestamp = datetime.datetime.utcnow()

   embed2 = discord.Embed(
    colour = dark_green
   )
   embed2.set_thumbnail(url=user1.avatar_url)
   embed2.set_author(name='Obiz | Economy',icon_url="https://cdn2.iconfinder.com/data/icons/bitsies/128/Info-256.png")

   embed2.add_field(name='New Economy in Obiz!', value = '`o.economy` to get the full list of commands.',inline = False)

   embed2.timestamp = datetime.datetime.utcnow()

   await ctx.reply(author,embed=embed,mention_author=False)
   await ctx.reply(author,embed=embed2,mention_author=False)

 @commands.command(pass_context=True, name="Help2")
 async def help2(self,ctx):
   author = ctx.message.author


   embed = discord.Embed(
    colour = dark_green
   )
   user = ctx.author
   embed.set_thumbnail(url=user.avatar_url)

   embed.set_author(name='Obiz | `o.help2` Moderation',icon_url="https://cdn2.iconfinder.com/data/icons/bitsies/128/Info-256.png")

   embed.add_field(name='o.information', value = '**What:** Information on the bot.\n**Usage:** o.info',inline = False)

   embed.add_field(name='o.status', value = '**What:** Status on bot.\n**Usage:** .status',inline = False)

   embed.add_field(name='o.purge', value = '**What:** Purge/clear multiple unwanted messages.\n**Usage:** o.purge `amount`',inline = False)

   embed.add_field(name='o.kick', value = '**What:** This will kick the user.\n**Usage:** o.kick `@user` `reason`',inline = False)

   embed.add_field(name='o.poll', value = '**What:** Creates a poll.\n**Usage 1:** o.poll "`question`" `option1` `option2`\n**Usage 2:** o.poll "`question`"',inline = False)

   embed.add_field(name='o.ping',value='**What:** Finds latency of bot.\n**Usage:** o.ping', inline = False)

   embed.add_field(name='o.invites',value='**What:**Shows how many invites given.\n**Usage:** o.invites', inline = False)

   embed.timestamp = datetime.datetime.utcnow()

   await ctx.reply(author,embed=embed, mention_author=False)

 @commands.command(name="help3")
 async def help3(self,ctx):
   author = ctx.message.author
   user = ctx.author


   embed = discord.Embed(
    colour = dark_green
   )

   embed.set_thumbnail(url=user.avatar_url)

   embed.set_author(name='Obiz | HELP3 Fun',icon_url="https://cdn2.iconfinder.com/data/icons/bitsies/128/Info-256.png")

   embed.add_field(name='o.meme', value = '**What:** Will get a meme from r/dankmemes.\n**Usage:** o.meme',inline = False)

   embed.add_field(name='o.mcmeme', value = '**What:** Will get a meme from r/minecraftmemes.\n**Usage:** o.mcmeme',inline = False)

   embed.add_field(name='o.animeme', value = '**What:** Will get a meme from r/Animemes.\n**Usage:** o.animeme',inline = False)

   embed.add_field(name='o.rand',value='**What** Will get a random number.\n**Usage:** o.rand', inline = False)

   embed.add_field(name='o.g',value='**What:** Asks to guess the number from 0 to 50.\n**Usage:** o.g', inline = False)

   embed.add_field(name='o.8ball',value='**What:** Ask and the 8ball shall tell.\n**Usage:** o.8b `question`', inline = False)

   embed.add_field(name='o.kill',value='**What:** Kill a member for fun.\n**Usage:** o.kill `@user`', inline = False)


   embed.timestamp = datetime.datetime.utcnow()
   await ctx.reply(author,embed=embed, mention_author=False)

 @commands.command(pass_context=True, name="Help4")
 async def help4(self,ctx):
   author = ctx.message.author
   user = ctx.author


   embed = discord.Embed(
    colour = dark_green
   )

   embed.set_thumbnail(url=user.avatar_url)

   embed.set_author(name='Obiz | HELP4 Other',icon_url="https://cdn2.iconfinder.com/data/icons/bitsies/128/Info-256.png")

   embed.add_field(name='o.whoisthebest', value = '`The Mid` ofcourse.',inline = False)

   embed.timestamp = datetime.datetime.utcnow()
   await ctx.reply(author,embed=embed, mention_author=False)

 @commands.command(name="whoisthebest")
 async def whoisthebest(self,ctx):
   await ctx.reply("Derpy Is The Best", mention_author=False)
  
 @commands.command(pass_context=True, name="nsfw")
 async def nsfw(self,ctx):
   author = ctx.message.author


   embed = discord.Embed(
    colour = discord.Colour.red()
   )

   embed.set_author(name='Obiz | NSFW',icon_url="https://upload.wikimedia.org/wikipedia/commons/thumb/8/8f/Flat_cross_icon.svg/1024px-Flat_cross_icon.svg.png")

   embed.add_field(name='Ass', value = '.ass', inline = False)

   embed.add_field(name='Hentai', value = '.hentai', inline = False)

   embed.add_field(name='Pussy', value = '.pussy', inline = False)

   embed.add_field(name='Porn', value = '.porn', inline = False)

   embed.add_field(name='Titty', value = '.tit', inline = False)

   embed.timestamp = datetime.datetime.utcnow()
   await ctx.reply(author,embed=embed, mention_author=False)

 
 @commands.command(name="Hi")
 async def hi(self,ctx):
   '''
   Hi! {.hi}
   '''
   await ctx.reply("hallo!")
  
 @commands.command(name="Yes")
 async def yes(self,ctx):
   '''
   yes! {.hi}
   '''
   await ctx.reply("yes")

 @commands.command(name="No")
 async def no(self,ctx):
   '''
   Hi! {.hi}
   '''
   await ctx.reply("no")

 @commands.command(name="Sudo")
 async def sudo(self,ctx, *, question):
   await ctx.channel.purge(limit=1)
   await ctx.send(f'{question}')

 @commands.command(name="8ball",aliases =['8b'])
 async def _8ball(self,ctx, *, question):
   '''
   Your magical 8 ball {.8b (Question)}
   '''
   responses = [
            "It is certain.",
            "It is decidedly so.",
            "Without a doubt.",
            "Yes - definitely.",
            "You may rely on it.",
            "As I see it, yes.",
            "Most likely.",
            "Outlook good.",
            "Yes.",
            "Signs point to yes.",
            "Reply hazy, try again.",
            "Ask again later.",
            "Better not tell you now.",
            "Cannot predict now.",
            "Concentrate and ask again.",
            "Don't count on it.",
            "My reply is no.",
            "My sources say no.",
            "Outlook not so good.",
            "Very doubtful."]
   await ctx.reply(f'Question: {question}\nAnswer: {random.choice(responses)}')

 @commands.command(name="Name picker",aliases =['np'])
 async def namepick(self,ctx, *, question):
   responses = [
            "Midhun",
            "Neo",
            "William.O",
            "Zac",
            "Parth",
            "Riley",
            "Noah",
            "Brendan",
            "Brendan",
            "Brendan",
            "Jess",
            "Flavio",
            "Xx_(Mindblown)_xX",
            "Boobee"]
   await ctx.reply(f'Question: {question}\nAnswer: {random.choice(responses)}')

 @commands.command(pass_context=True, name="economy")
 async def economy(self,ctx):
   author = ctx.message.author
   user = ctx.author


   embed = discord.Embed(
    colour = dark_green
   )

   embed.set_thumbnail(url=user.avatar_url)

   embed.set_author(name='Obiz | Economy Other',icon_url="https://cdn2.iconfinder.com/data/icons/bitsies/128/Info-256.png")

   embed.add_field(name='o.bal or o.balance', value = '**What:** Balance of your account.\n**Usage:** o.bal',inline = True)
   embed.add_field(name='o.buy', value = '**What:** Buy items.\n**Usage:** o.buy `item` `amount`',inline = True)
   embed.add_field(name='o.withdraw', value = '**What:** Send money to others.\n**Usage:** o.wd `amount in bank`',inline = True)
   embed.add_field(name='o.deposit', value = '**What:** Send money to others.\n**Usage:** o.dep `amount in wallet`',inline = True)
   embed.add_field(name='o.sell', value = '**What:** Sell unwanted items.\n**Usage:** o.sell `item`',inline = True)
   embed.add_field(name='o.rob', value = '**What:** Steal money from others.\n**Usage:** o.rob `@user`',inline = True)
   embed.add_field(name='o.beg', value = '**What:** Beg for free money.\n**Usage:** o.beg',inline = True)
   embed.add_field(name='o.shop', value = '**What:** Look at Goods.\n**Usage:** o.shop',inline = True)
   embed.add_field(name='o.inv', value = '**What:** Inventory of your stuff. \n**Usage:** o.inv',inline = True)
   embed.add_field(name='o.send', value = '**What:** Send money to others.\n**Usage:** o.sm `@user` `amount in wallet`',inline = True)
   embed.add_field(name='o.onlypan', value = '**What:** uhhhhh.\n**Usage:** o.onlypan',inline = True)
   embed.add_field(name='o.leaderboard', value = '**What:** See wealth leaderboard.\n**Usage:** o.lb',inline = True)
   embed.add_field(name='o.stonks', value = '**What:** EZ money.\n**Usage:** o.stonks',inline = True)
   embed.add_field(name='o.slots', value = '**What:** Risky lot of money.\n**Usage:** o.slots `amount in wallet`',inline = True)
   embed.add_field(name='o.rich', value = '**What:** See a specific persons bal.\n**Usage:** o.rich `@user`',inline = True)
   

   embed.timestamp = datetime.datetime.utcnow()
   await ctx.reply(author,embed=embed, mention_author=False)

def setup(bot):
	bot.add_cog(MainCommands(bot))

@bot.event
async def on_button_click(interaction):
    await interaction.respond(type=6)
    await interaction.author.send("Click")