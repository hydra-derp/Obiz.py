import discord
import random
from discord.ext import commands
import aiohttp

def __init__(self, bot): 
   self.bot = bot

class Game (commands.Cog , name='2.Games') :
 ##main commands start here##
  @commands.command(name="Guessing Game",aliases=['g'])
  async def game(self, ctx):
    '''
    Guess the number from 0-50 {.g (number)}
    '''
    number = random.randint(0, 50)
    for i in range(0, 1000):
        await ctx.send('Guess a number!')
        response = await self.bot.wait_for('message')
        guess = int(response.content)
        if guess > number:
            await ctx.send('smaller')
        elif guess < number:
            await ctx.send('bigger')
        else:
            await ctx.send('Correct! you got it!')


def setup(bot):
 bot.add_cog(Game(bot))